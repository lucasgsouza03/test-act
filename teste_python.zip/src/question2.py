class Orders:
    def combine_orders(self, requests, n_max):
        pass